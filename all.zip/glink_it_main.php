<?php

$token = $_GET['uid'];
$name = "";

$str = file_get_contents('http://localhost/user_info.php');

$json = json_decode($str, true); 

 

 
  foreach ($json as $row) {
     if( $token ==$row['token'])
	  {
           $name =  $row['name'];
	  }
    
  
}
 
?>

 
<html xmlns="http://www.w3.org/1999/xhtml" >

<head id="ctl00_Head1"><meta id="ctl00_FirstCtrlID" http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
    <base href='http://192.168.0.181/' />
    <!-- Mimic Internet Explorer 7 -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><title>
	G-Link - Support Request
</title><link rel="stylesheet" type="text/css" href="/Css/glinkCommon.css?v=14.1016" /><link rel="stylesheet" type="text/css" href="/Css/Common.css" /><link rel="stylesheet" type="text/css" media="print" href="/Css/PrinterFriendly.css" /><link rel="shortcut icon" href="/image/shotcut.ico" /><link rel="apple-touch-icon-precomposed" sizes="114x114" href="../../Master/image/apple-touch-icon-114x114.png" /><link rel="apple-touch-icon-precomposed" sizes="72x72" href="../../Master/image/apple-touch-icon-72x72.png" /><link rel="apple-touch-icon-precomposed" href="../../Master/image/apple-touch-icon-precomposed.png" />    
    
    <!-- common -->
    <script src="/js/common.js?v=1.21" type="text/javascript"></script> 

<link href="/css/DevSite.css" type="text/css" rel="stylesheet" /><link href="../../css/topIcon/ico_it.css" type="text/css" rel="stylesheet" /><style type="text/css">
	.ctl00_cphMainContent_siteID_menuCategory_0 { background-color:white;visibility:hidden;display:none;position:absolute;left:0px;top:0px; }
	.ctl00_cphMainContent_siteID_menuCategory_1 { text-decoration:none; }
	.ctl00_cphMainContent_siteID_menuCategory_2 {  }
p
</style></head>

<body class="MasterBody">
    <div id="mainBodyContainer">

        <div id ="bodyContent">    

            <form name="aspnetForm" method="post" action="IT_SupportRequestList.aspx?1=1" id="aspnetForm">
<div>
 

</div>
 
        <div class="header_top"></div>
                
        <div class="header_middle">
            <div class="logo_glink"></div>
                
            <div class="nav">
                <ul>
                    
                        <li class="nav_ef">
                            <a href=""  target="_parent" >E-Form</a>
                        </li>
                    
                </ul>
                <div class="userPage" >
                    <span style="color:#FA5705">Welcome</span>&nbsp;<span>Olive Network System Study</span>
                </div>
             </div>
         </div>   
         
      
<div id="gnb" >
    <div class="navi">
        <ul class="mainPageUL">
        
            <li class="docu" style="list-style-type:none; padding:0px; margin:0px;">
                <a href="#">Documents</a>
            </li>
        
            <li class="it" style="list-style-type:none; padding:0px; margin:0px;">
               <a href=<?php echo "http://glinkglink-php-it-main.marathon.l4lb.thisdcos.directory/glink_it_main.php?uid=".$_GET['uid'] ?>>IT</a>
            </li>
        
            <li class="reports" style="list-style-type:none; padding:0px; margin:0px;">
                <a href=<?php echo "http://glinkglink-php-report-main.marathon.l4lb.thisdcos.directory/glink_report_main.php?uid=".$_GET['uid'] ?>>Reports</a>
            </li>
        
        </ul>
    </div>
</div>    
    
                    <!-----------------Header:end--------------------->	      

                    <!----------------MainContent: start-------------------->                    
                    <div id="container">
                        

   

<script type="text/javascript">

 
    function goURLPopup(strURL) {
        //strURL = encodeURI(strURL);
        var cw = 1025;
        var ch = 730;
        var wLo = (eval(screen.width) - cw) / 2;
        var hLo = (eval(screen.height) - ch) / 2;
        window.open(encodeURI(strURL), "eHR", "top=" + hLo + ",left=" + wLo + ",height=" + ch + ",width=" + cw + ",status=no,oolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes,titlebar=no");
    }
</script>
 <div class="bx_spot">
        <div class="ico_spot">
        </div>
        <div class="spottitle">
            <span id="ctl00_cphMainContent_siteID_lblCategoryTitle">Support Request</span>
        </div>
        <div class="spottext">
            To request for any support or assistance from IT. Applicable for both HQ IT and local IT support
        </div>
        <div class="btn_bizschdule">
        </div>
 </div>
 <div class="snbwrap">
    <div class="account">
        <div class="ico_user"></div>
        

<div class="user" >
    <a href="javascript:goURLPopup('<?php echo "http://glinkglink-php-popup.marathon.l4lb.thisdcos.directory/glink_popup.php?uid=".$_GET['uid']?>')">
	<!-- <a href=<?php echo "http://glinkglink-php-popup.marathon.l4lb.thisdcos.directory/glink_popup.php?uid=".$_GET['uid']?>> -->
            <span id="ctl00_cphMainContent_siteID_userNameAndDate_lblUser" style="color:#000000;vertical-align:top;">
			<?php echo $name ?></span>
    </a>
</div>
<div class="time">
        <span id="ctl00_cphMainContent_siteID_userNameAndDate_lblClock"><?php echo date("Ymd") ?></span>
</div>

	</div>
        
    <div class="snb">
        <div class="snbtitle">
            <span id="ctl00_cphMainContent_siteID_lblTitle">IT</span>
        </div>

        
            
        <a href="#ctl00_cphMainContent_siteID_menuCategory_SkipLink" style="display:inline-block;height:1px;width:1px;"><img src="/WebResource.axd?d=TJpFZ0YcEsW5ZWhA9eTCq5P1uWyPQRBNEDcNxLo9QjxIGhykyJzCcecW7qqEeZgK8krEI_vkMKTnlXWz27p47O_7iGU1&amp;t=636284921597151108" alt="Skip Navigation Links" style="border-width:0px;" /></a><div id="ctl00_cphMainContent_siteID_menuCategory">
	<span><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/ChangePasswordConfirmation.aspx">Change Password</a></span><br /><span title="For request of network, systems and email ID accounts."><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/ITService/IDRequest/IT_IDRequestList.aspx">ID Request</a></span><br /><span title="To request for new project."><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/ITService/ProjectRequest/IT_ProjectRequestList.aspx">Project Request</a></span><br /><span title="To request for any support or assistance from IT. Applicable for both HQ IT and local IT support"><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/ITService/SupportRequest/IT_SupportRequestList.aspx">Support Request</a></span><br />
</div><a name="ctl00_cphMainContent_siteID_menuCategory_SkipLink"></a>
        
        
        
        
    </div>			
 </div>


        
    <div class="contentswrap">
        <table class="tblMain">
            <tr>
                <td colspan="2" align="center" class="tdError">
                    
                            
                        
                </td>
            </tr>
            <tr> 
                <td class="tdTopMenu">
                    <table class="tblMain">
                        
                        <tr>
                            <td colspan="4" class="tdHeader">
                                <table cellpadding="0" cellspacing="0" border="0"  class="tblMain">
                                    <tr>
                                        <td class="tdHeader">                                            
                                            <span id="ctl00_cphMainContent_lbl_Header">Support Request List</span>
                                        </td>
                                        <td class="tdTopProgress">
                                            
                                        </td>
                                        <td width="200px" align="right" valign="middle">
                                            <input type="image" name="ctl00$cphMainContent$btnCreate" id="ctl00_cphMainContent_btnCreate" src="/Image/btnNew_C.gif" align="middle" style="border-width:0px;" />
                                            <input type="image" name="ctl00$cphMainContent$btnSearch" id="ctl00_cphMainContent_btnSearch" src="/Image/btnSearch_C.gif" align="middle" style="border-width:0px;" />
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td class="tdLblNormal">                                
                                 <span id="ctl00_cphMainContent_lbl_RequestID">Request ID</span>
                            </td>
                            <td class="td3TxtNormal" colspan="3">
                                <input name="ctl00$cphMainContent$txtRequestID" type="text" maxlength="20" id="ctl00_cphMainContent_txtRequestID" style="width:200px;" />
                            </td>
                        </tr>
                        <tr>
                            <td class="tdLblNormal">                                
                                 <span id="ctl00_cphMainContent_lbl_System">System</span>
                            </td>
                            <td class="tdTxtNormal">
                                <select name="ctl00$cphMainContent$cboSystem" id="ctl00_cphMainContent_cboSystem" style="width:205px;">
	<option selected="selected" value="ALL">ALL</option>
	<option value="SYS0003">Ailis XE</option>
	<option value="SYS0013">G-Link</option>
	<option value="SYS0017">GCC</option>
	<option value="SYS0023">GNEXS (Parcel Delivery)</option>
	<option value="SYS0014">InfraStructure (PC/Virus/Phone/Fax)</option>
	<option value="SYS0021">LPP</option>
	<option value="SYS0025">MDG S/4 HANA System</option>
	<option value="SYS0022">MDM</option>
	<option value="SYS0024">nSolution</option>
	<option value="SYS0020">SAP</option>
	<option value="SYS0026">SAP S/4 HANA System</option>

</select>
                            </td>
                            <td class="tdLblNormal">                                
                                 <span id="ctl00_cphMainContent_lbl_Status">Status</span>
                            </td>
                            <td class="tdTxtNormal">
                                <select name="ctl00$cphMainContent$cboStatus" id="ctl00_cphMainContent_cboStatus" style="width:205px;">
	<option selected="selected" value="-1">=ALL=</option>
	<option value="999">=For My Action=</option>
	<option value="0">New</option>
	<option value="15">Request More Information</option>
	<option value="20">Processing</option>
	<option value="25">Pending for third party reply</option>
	<option value="30">Pending for user action</option>
	<option value="40">Pending for user completion</option>
	<option value="10">Re-Open</option>
	<option value="50">Closed</option>
	<option value="60">Rejected</option>
	<option value="70">Transfer to HQ</option>
	<option value="90">Force Closed</option>

</select>
                            </td>
                        </tr>
                        <tr>
                            <td class="tdLblNormal">                                
                                <span id="ctl00_cphMainContent_lbl_Subject">Subject</span>
                            </td>
                            <td class="td3TxtNormal" colspan="3">
                                <input name="ctl00$cphMainContent$txtSubject" type="text" maxlength="100" id="ctl00_cphMainContent_txtSubject" style="width:570px;" />
                            </td>
                        </tr>
                        <tr>
                            <td class="tdLblNormal">                                
                              <span id="ctl00_cphMainContent_lbl_Comment">Comment</span>
                             </td>
                            <td class="td3TxtNormal" colspan="3">
                                <input name="ctl00$cphMainContent$txtComment" type="text" maxlength="200" id="ctl00_cphMainContent_txtComment" style="width:570px;" />
                            </td>
                        </tr>
                        <tr>
                            <td class="tdLblNormal">                                
                                <span id="ctl00_cphMainContent_lbl_Requesteddate">Requested Date</span>
                            </td>
                            <td class="td3TxtNormal" colspan="3">
                                <span id="ctl00_cphMainContent_cldFrom" CalendarLocation="Bottom" OnClick="SetCalendarPopup(this)"><input name="ctl00$cphMainContent$cldFrom$textBox" type="text" value="16/06/2019" readonly="readonly" id="ctl00_cphMainContent_cldFrom_textBox" onclick="CalendarPopup_FindCalendar('ctl00_cphMainContent_cldFrom').Show();" style="width:200px;" /><img id="ctl00_cphMainContent_cldFrom_image" onclick="CalendarPopup_FindCalendar('ctl00_cphMainContent_cldFrom').Show();" src="/Image/Calendar.gif" style="border-width:0px;vertical-align:text-bottom;cursor:pointer;" /><input name="ctl00$cphMainContent$cldFrom$hidden" type="hidden" id="ctl00_cphMainContent_cldFrom_hidden" value="16/06/2019" /><input name="ctl00$cphMainContent$cldFrom$validateHidden" type="hidden" id="ctl00_cphMainContent_cldFrom_validateHidden" value="06/16/2019" /><input name="ctl00$cphMainContent$cldFrom$enableHidden" type="hidden" id="ctl00_cphMainContent_cldFrom_enableHidden" value="true" /><div id="ctl00_cphMainContent_cldFrom_calendar" style="z-index:5001;position:absolute;display:none;float:left;"></div><div id="ctl00_cphMainContent_cldFrom_monthYear" style="z-index:5003;position:absolute;display:none;float:left;"></div></span>
                                &nbsp;~&nbsp;
                                <span id="ctl00_cphMainContent_cldTo" CalendarLocation="Bottom" OnClick="SetCalendarPopup(this)"><input name="ctl00$cphMainContent$cldTo$textBox" type="text" value="16/09/2019" readonly="readonly" id="ctl00_cphMainContent_cldTo_textBox" onclick="CalendarPopup_FindCalendar('ctl00_cphMainContent_cldTo').Show();" style="width:200px;" /><img id="ctl00_cphMainContent_cldTo_image" onclick="CalendarPopup_FindCalendar('ctl00_cphMainContent_cldTo').Show();" src="/Image/Calendar.gif" style="border-width:0px;vertical-align:text-bottom;cursor:pointer;" /><input name="ctl00$cphMainContent$cldTo$hidden" type="hidden" id="ctl00_cphMainContent_cldTo_hidden" value="16/09/2019" /><input name="ctl00$cphMainContent$cldTo$validateHidden" type="hidden" id="ctl00_cphMainContent_cldTo_validateHidden" value="09/16/2019" /><input name="ctl00$cphMainContent$cldTo$enableHidden" type="hidden" id="ctl00_cphMainContent_cldTo_enableHidden" value="true" /><div id="ctl00_cphMainContent_cldTo_calendar" style="z-index:5001;position:absolute;display:none;float:left;"></div><div id="ctl00_cphMainContent_cldTo_monthYear" style="z-index:5003;position:absolute;display:none;float:left;"></div></span>
                            </td>
                        </tr>
                        

                        
                        
                        
                        
                        
                        <tr>
                            <td colspan="4" class="tdBreak">
                            </td>
                        </tr>
                        <div id="ctl00_cphMainContent_pnAllList">
	
                            <tr>
                                <td colspan="4" class="tdGrid">
                                    
                                            <span id="ctl00_cphMainContent_lblNoRecord" style="font-style:italic;"></span>
                                            <div>
		<table class="dtGridView" cellspacing="2" border="0" id="ctl00_cphMainContent_gvSupportRequest" style="width:100%;">
			<tr class="tdTxtNormal">
				<td colspan="7">No Record Found.</td>
			</tr>
		</table>
	</div>
                                        
                                    
                                </td>
                            </tr>   
                        
</div>
                    </table>
                </td>
            </tr>
        </table>
    </div>

                    </div>
                    <!----------------MainContent: end  -------------------->  
                    
                    <div class="push"></div>
            
<script type="text/javascript">
//<![CDATA[
var eWorld_UI_CalendarPopups =  new Array('ctl00_cphMainContent_cldFrom', 'ctl00_cphMainContent_cldTo');
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var ctl00_cphMainContent_cldFrom = document.all ? document.all["ctl00_cphMainContent_cldFrom"] : document.getElementById("ctl00_cphMainContent_cldFrom");
ctl00_cphMainContent_cldFrom.calendar = "new CalendarPopup_Calendar(\'ctl00_cphMainContent_cldFrom\', \'ctl00_cphMainContent_cldFrom_textBox\', \'ctl00_cphMainContent_cldFrom_label\', \'ctl00_cphMainContent_cldFrom_button\', \'ctl00_cphMainContent_cldFrom_image\', \'ctl00_cphMainContent_cldFrom_hidden\', \'ctl00_cphMainContent_cldFrom_validateHidden\', \'ctl00_cphMainContent_cldFrom_enableHidden\', \'ctl00_cphMainContent_cldFrom_calendar\', \'ctl00_cphMainContent_cldFrom_monthYear\', 2, new Array(\'January\',\'February\',\'March\',\'April\',\'May\',\'June\',\'July\',\'August\',\'September\',\'October\',\'November\',\'December\'), new Array(\'M\', \'T\', \'W\', \'T\', \'F\', \'S\', \'S\'), 1, 6, 5, false, \'01/01/1000\', \'12/31/9999\', 1, false, 0, 0, false, \'Clear Date\', \'Select a Date\', false, \'Today\\\'s Date:\', \'\', \'\', \'\', \'\', \'\', -1, \'06/16/2019\', \'Apply\', \'Cancel\', \'\', false, false, false, false)";
ctl00_cphMainContent_cldFrom.calendarStyle = "new CalendarPopup_Style(\'ctl00_cphMainContent_cldFrom\', \"style=\'color:Black;background-color:LightGrey;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:Silver;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:Gray;background-color:WhiteSmoke;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:White;background-color:#86ADE4;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:White;background-color:#86ADE4;font-family:Tahoma,Arial,sans-serif;font-size:Small;font-weight:bold;cursor:pointer;\'\", \"style=\'color:Black;background-color:White;font-family:Tahoma,Arial,sans-serif;font-size:Small;width:20px;\'\", \"style=\'color:Black;background-color:White;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:White;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:#86ADE4;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'font-style:italic;cursor:pointer;\'\", \"style=\'font-style:italic;cursor:pointer;\'\", \"style=\'color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:XX-Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:#B5D8FA;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:XX-Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:LightGrey;border-color:Black;border-width:1px;border-style:solid;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:XX-Small;cursor:pointer;\'\", \"style=\'color:Gray;background-color:#E5E5E5;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:XX-Small;\'\")";
ctl00_cphMainContent_cldFrom.specialDays = "";
var ctl00_cphMainContent_cldTo = document.all ? document.all["ctl00_cphMainContent_cldTo"] : document.getElementById("ctl00_cphMainContent_cldTo");
ctl00_cphMainContent_cldTo.calendar = "new CalendarPopup_Calendar(\'ctl00_cphMainContent_cldTo\', \'ctl00_cphMainContent_cldTo_textBox\', \'ctl00_cphMainContent_cldTo_label\', \'ctl00_cphMainContent_cldTo_button\', \'ctl00_cphMainContent_cldTo_image\', \'ctl00_cphMainContent_cldTo_hidden\', \'ctl00_cphMainContent_cldTo_validateHidden\', \'ctl00_cphMainContent_cldTo_enableHidden\', \'ctl00_cphMainContent_cldTo_calendar\', \'ctl00_cphMainContent_cldTo_monthYear\', 2, new Array(\'January\',\'February\',\'March\',\'April\',\'May\',\'June\',\'July\',\'August\',\'September\',\'October\',\'November\',\'December\'), new Array(\'M\', \'T\', \'W\', \'T\', \'F\', \'S\', \'S\'), 1, 6, 5, false, \'01/01/1000\', \'12/31/9999\', 1, false, 0, 0, false, \'Clear Date\', \'Select a Date\', false, \'Today\\\'s Date:\', \'\', \'\', \'\', \'\', \'\', -1, \'09/16/2019\', \'Apply\', \'Cancel\', \'\', false, false, false, false)";
ctl00_cphMainContent_cldTo.calendarStyle = "new CalendarPopup_Style(\'ctl00_cphMainContent_cldTo\', \"style=\'color:Black;background-color:LightGrey;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:Silver;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:Gray;background-color:WhiteSmoke;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:White;background-color:#86ADE4;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:White;background-color:#86ADE4;font-family:Tahoma,Arial,sans-serif;font-size:Small;font-weight:bold;cursor:pointer;\'\", \"style=\'color:Black;background-color:White;font-family:Tahoma,Arial,sans-serif;font-size:Small;width:20px;\'\", \"style=\'color:Black;background-color:White;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:White;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:#86ADE4;font-family:Tahoma,Arial,sans-serif;font-size:Small;cursor:pointer;\'\", \"style=\'font-style:italic;cursor:pointer;\'\", \"style=\'font-style:italic;cursor:pointer;\'\", \"style=\'color:Black;background-color:White;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:XX-Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:#B5D8FA;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:XX-Small;cursor:pointer;\'\", \"style=\'color:Black;background-color:LightGrey;border-color:Black;border-width:1px;border-style:solid;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:XX-Small;cursor:pointer;\'\", \"style=\'color:Gray;background-color:#E5E5E5;font-family:Verdana,Helvetica,Tahoma,Arial;font-size:XX-Small;\'\")";
ctl00_cphMainContent_cldTo.specialDays = "";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[
var eWorld_CalendarPopup_Styles = new Array();eWorld_CalendarPopup_Calendars = new Array();eWorld_CalendarPopup_SpecialDays = new Array();CalendarPopup_InitializeCompatibility();Sys.Application.initialize();
//]]>
</script>
</form>
    </div>

    <!----------------Footer: start here -------------------->
    <div id="Error" style="visibility: hidden;">
        An error has occured while trying to process your request.
    </div>    
    
        <div id="footer">
            <span class="footerlogo">
                <img id="ctl00_Image1" src="../../Image/cjlogo.png" align="middle" style="border-width:0px;" />	
            </span>
            <span id="ctl00_spaCopyright" class="footerline1">Copyright © CJ Logistics Corporation. &nbsp;</span><span id="ctl00_spaCopyright2" class="footerline3">All rights reserved.</span>&nbsp;<span  class="footerline3" onclick="javascript:VoidOpen();">.</span><br/>
            <span class="footerline2"><b>www.cjlogistics.com</b></span> 
        </div>
    
    <!----------------Footer : end here -------------------->  
    
    </div>  

</body>
</html>
