<?php

$token = $_GET['uid'];
$name = "";

$str = file_get_contents('http://localhost/user_info.php');

$json = json_decode($str, true); 

 

 
  foreach ($json as $row) {
     if( $token ==$row['token'])
	  {
           $name =  $row['name'];
	  }
    
  
}
 
?>


<html xmlns="http://www.w3.org/1999/xhtml" >

<head id="ctl00_Head1"><meta id="ctl00_FirstCtrlID" http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
    <base href='http://192.168.0.181/' />
    <!-- Mimic Internet Explorer 7 -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><title>
	G-Link - Reports
</title><link rel="stylesheet" type="text/css" href="/Css/glinkCommon.css?v=14.1016" /><link rel="stylesheet" type="text/css" href="/Css/Common.css" /><link rel="stylesheet" type="text/css" media="print" href="/Css/PrinterFriendly.css" /><link rel="shortcut icon" href="/image/shotcut.ico" /><link rel="apple-touch-icon-precomposed" sizes="114x114" href="Master/image/apple-touch-icon-114x114.png" /><link rel="apple-touch-icon-precomposed" sizes="72x72" href="Master/image/apple-touch-icon-72x72.png" /><link rel="apple-touch-icon-precomposed" href="Master/image/apple-touch-icon-precomposed.png" />    
    
    <!-- common -->
    <script src="/js/common.js?v=1.21" type="text/javascript"></script> 

<link href="/css/DevSite.css" type="text/css" rel="stylesheet" /><link href="css/topIcon/ico_reports.css" type="text/css" rel="stylesheet" /><style type="text/css">
	.ctl00_cphMainContent_siteID_menuCategory_0 { background-color:white;visibility:hidden;display:none;position:absolute;left:0px;top:0px; }
	.ctl00_cphMainContent_siteID_menuCategory_1 { text-decoration:none; }
	.ctl00_cphMainContent_siteID_menuCategory_2 {  }

</style></head>

<body class="MasterBody">
    <div id="mainBodyContainer">

        <div id ="bodyContent">    

            <form name="aspnetForm" method="post" action="Report_startup.aspx" id="aspnetForm">
 

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=1ICNiPk_kPUnjbv1bLpMLMm6sz2FselulhoegtBtkSpdnqug65nzgidAk7TodvU8VoMfpD_1ICUX-ewgIS00oQy-Epc1&amp;t=636284921597151108" type="text/javascript"></script>


<script src="/ScriptResource.axd?d=twFX1X2TlhojxqLPtojI9amwntol9qJxLAPpwC-ChbxuKqW0-7Sua9yoe5Qkr5FOvX3AOlA55P6i-d1NVmbiZRGHX9Aqog8-9XcnV3EY6oMjTDwJH7m-nubKyjJ_rakUnI0vFnjPlo6fyDLvu5OszR5SKjUODicMjVTtDr9a8mTozKOW0&amp;t=635845620641720586" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=gChqG7DVjPdDvpa96dW6B4byp98KWaTwZsGoem2-92Dn3XIEw9bSRNm_pGEQilvtXsT-oVubxMFyjO3KML5xKqh6rgyLp__j2PqOUUTwNk1jZYzwevTWtsHPey443tZ3gDg0YmW5N1asGGJ9ltuJrkUCDMa8sJTfyHolmvY6kTAtu61_0&amp;t=635845620641720586" type="text/javascript"></script>
<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="474F7BB9" />
</div>
                    <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager', document.getElementById('aspnetForm'));
Sys.WebForms.PageRequestManager.getInstance()._updateControls([], [], [], 90);
//]]>
</script>

        		  

                    <!-----------------Header:start--------------------->	    
                    


 
        <div class="header_top"></div>
                
        <div class="header_middle">
            <div class="logo_glink"></div>
                
            <div class="nav">
                <ul>
                    
                        <li class="nav_ef">
                            <a href="/DocumentStatus/DS_Pending.aspx"  target="_parent" >E-Form</a>
                        </li>
                    
                </ul>
                <div class="userPage" >
                    <span style="color:#FA5705">Welcome</span>&nbsp;<span>Olive Network System Study</span>
                </div>
             </div>
         </div>   
         
      
<div id="gnb" >
    <div class="navi">
        <ul class="mainPageUL">
        
            <li class="docu" style="list-style-type:none; padding:0px; margin:0px;">
              <a>Documents</a>
            </li>
        
           <li class="it" style="list-style-type:none; padding:0px; margin:0px;">
               <a href=<?php echo "http://glinkglink-php-it-main.marathon.l4lb.thisdcos.directory/glink_it_main.php?uid=".$_GET['uid'] ?>>IT</a>
            </li>
        
            <li class="reports" style="list-style-type:none; padding:0px; margin:0px;">
                <a href=<?php echo "http://glinkglink-php-report-main.marathon.l4lb.thisdcos.directory/glink_report_main.php?uid=".$_GET['uid'] ?>>Reports</a>
            </li>
        
        </ul>
    </div>
</div>    
    
                    <!-----------------Header:end--------------------->	      

                    <!----------------MainContent: start-------------------->                    
                    <div id="container">
                        
    

   

<script type="text/javascript">

    function goURL(strURL) {
        //strURL = encodeURI(strURL);
        window.open(encodeURI(strURL), '_self');
    }
    function goURLPopup(strURL) {
        //strURL = encodeURI(strURL);
        var cw = 1025;
        var ch = 730;
        var wLo = (eval(screen.width) - cw) / 2;
        var hLo = (eval(screen.height) - ch) / 2;
        window.open(encodeURI(strURL), "eHR", "top=" + hLo + ",left=" + wLo + ",height=" + ch + ",width=" + cw + ",status=no,oolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes,titlebar=no");
    }
</script>
 <div class="bx_spot">
        <div class="ico_spot">
        </div>
        <div class="spottitle">
            <span id="ctl00_cphMainContent_siteID_lblCategoryTitle">Reports</span>
        </div>
        <div class="spottext">
            Reports download module for authorised personnel only.
        </div>
        <div class="btn_bizschdule">
        </div>
 </div>
 <div class="snbwrap">
    <div class="account">
        <div class="ico_user"></div>
        

<div class="user" >
    <!-- <a href="javascript:ShowEmployeeInfo()"> -->
	<a href=<?php echo "http://glinkglink-php-popup.marathon.l4lb.thisdcos.directory/glink_popup.php?uid=".$_GET['uid'] ?>>
            <span id="ctl00_cphMainContent_siteID_userNameAndDate_lblUser" style="color:#000000;vertical-align:top;">
			<?php echo $name?></span>
    </a>
</div>
<div class="time">
        <span id="ctl00_cphMainContent_siteID_userNameAndDate_lblClock"><?php echo date("Ymd") ?></span>
</div>

	</div>
        
    <div class="snb">
        <div class="snbtitle">
            <span id="ctl00_cphMainContent_siteID_lblTitle">Reports</span>
        </div>

        
            
        <a href="#ctl00_cphMainContent_siteID_menuCategory_SkipLink" style="display:inline-block;height:1px;width:1px;"><img src="/WebResource.axd?d=TJpFZ0YcEsW5ZWhA9eTCq5P1uWyPQRBNEDcNxLo9QjxIGhykyJzCcecW7qqEeZgK8krEI_vkMKTnlXWz27p47O_7iGU1&amp;t=636284921597151108" alt="Skip Navigation Links" style="border-width:0px;" /></a><div id="ctl00_cphMainContent_siteID_menuCategory">
	<span title="IT Project Request Report"><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/Report_startup.aspx?main=ProjReq">IT Project Request Report</a></span><br /><span title="Extract data and reports download on IT Project Request"><img src="/WebResource.axd?d=TJpFZ0YcEsW5ZWhA9eTCq5P1uWyPQRBNEDcNxLo9QjxIGhykyJzCcecW7qqEeZgK8krEI_vkMKTnlXWz27p47O_7iGU1&amp;t=636284921597151108" alt="" style="height:1px;width:16px;border-width:0px;" /><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/ITService/Report/IT_ProjReq_RawData.aspx">ProjReq Data Download</a></span><br /><span title="IT Support Request Report"><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/Report_startup.aspx?main=IT_SuppReq">IT Support Request Report</a></span><br /><span title="KPI - Based on IT Staff's response time"><img src="/WebResource.axd?d=TJpFZ0YcEsW5ZWhA9eTCq5P1uWyPQRBNEDcNxLo9QjxIGhykyJzCcecW7qqEeZgK8krEI_vkMKTnlXWz27p47O_7iGU1&amp;t=636284921597151108" alt="" style="height:1px;width:16px;border-width:0px;" /><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/ITService/Report/IT_SuppReq_BySystem.aspx">SR KPI - By System Type</a></span><br /><span title="KPI - based on user evaluation"><img src="/WebResource.axd?d=TJpFZ0YcEsW5ZWhA9eTCq5P1uWyPQRBNEDcNxLo9QjxIGhykyJzCcecW7qqEeZgK8krEI_vkMKTnlXWz27p47O_7iGU1&amp;t=636284921597151108" alt="" style="height:1px;width:16px;border-width:0px;" /><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/ITService/Report/IT_SuppReq_ByStaff.aspx">SR KPI - By User Evaluation</a></span><br /><span title="Extract IT Support Request Raw Data"><img src="/WebResource.axd?d=TJpFZ0YcEsW5ZWhA9eTCq5P1uWyPQRBNEDcNxLo9QjxIGhykyJzCcecW7qqEeZgK8krEI_vkMKTnlXWz27p47O_7iGU1&amp;t=636284921597151108" alt="" style="height:1px;width:16px;border-width:0px;" /><a class="ctl00_cphMainContent_siteID_menuCategory_1" href="/ITService/Report/IT_SuppReq_RawData.aspx">SR Raw Data Download</a></span><br />
</div><a name="ctl00_cphMainContent_siteID_menuCategory_SkipLink"></a>
        
        
        
        
    </div>			
 </div>


        
    <div class="contentswrap">
        <center>
            <br /><br />
            <img src="/Image/reports.jpg" alt=""/>&nbsp;<br />
        </center>
        <table class="tblMain" >
        <tr>
            <td class="tdBreak"></td>
        </tr> 
        </table>
    </div>

                    </div>
                    <!----------------MainContent: end  -------------------->  
                    
                    <div class="push"></div>
            

<script type="text/javascript">
//<![CDATA[
Sys.Application.initialize();
//]]>
</script>
</form>
    </div>

    <!----------------Footer: start here -------------------->
    <div id="Error" style="visibility: hidden;">
        An error has occured while trying to process your request.
    </div>    
    
        <div id="footer">
            <span class="footerlogo">
                <img id="ctl00_Image1" src="Image/cjlogo.png" align="middle" style="border-width:0px;" />	
            </span>
            <span id="ctl00_spaCopyright" class="footerline1">Copyright © CJ Logistics Corporation. &nbsp;</span><span id="ctl00_spaCopyright2" class="footerline3">All rights reserved.</span>&nbsp;<span  class="footerline3" onclick="javascript:VoidOpen();">.</span><br/>
            <span class="footerline2"><b>www.cjlogistics.com</b></span> 
        </div>
    
    <!----------------Footer : end here -------------------->  
    
    </div>  

</body>
</html>
