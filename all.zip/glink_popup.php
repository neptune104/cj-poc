
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1"><title>
	Employee Information
</title>
<base href='http://192.168.0.181' />
<link href="/Css/Common.css" type="text/css" rel="stylesheet" /></head>

<script language="javascript">
    function FileUpload()
    {
        var cw = 460;
		var ch = 200;
		var wLo = (eval(screen.width) - cw) /2;
		var hLo = (eval(screen.height) - ch) /2; 
		window.open("/Administration/PopUp/AD_PopUp_FileUpload.aspx?type=Employee_Pic", "FileUpload2", "top=" + hLo + ",left=" + wLo + ",height=" + ch + ",width=" + cw + ",status=yes,toolbar=no,menubar=no,location=no,scrollbars=yes");
    }
    
    function GetFile()
    {
        __doPostBack('imgPic','');
    }
    	
	function GetFileFromFrame()
	{
	    window.frames["FUupload"].UploadFile();
	    return true;
	}
	

	function PopPage()
	{
        var cw = 650;
        var ch = 450;
        var wLo = (eval(screen.width) - cw) /6;
        var hLo = (eval(screen.height) - ch) /6; 

        var thisWin = window.open("", "", "top=" + hLo + ",left=" + wLo + ",height=" + ch + ",width=" + cw + ",status=no,toolbar=no,menubar=no,location=no,scrollbars=no");
       
        if(thisWin.location == "about:blank")
        {
            window.location.href = window.location.href;
            thisWin.location.href = "/Administration/PopUp/AD_PopUp_SnapInfoPreview.aspx";	        
            thisWin.focus();
        }
        else
        {
            thisWin.focus();
        }
	}	
</script>

<body topmargin="10px" leftmargin="12px">
    <form name="form1" method="post" action="AD_PopUp_EmployeeInfo.aspx?Type=view" onsubmit="javascript:return WebForm_OnSubmit();" id="form1">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTE4MjQwMTgzMA9kFgICAQ9kFjACBw8PFgIeBFRleHQFFEVtcGxveWVlIEluZm9ybWF0aW9uZGQCCQ8PFgIfAAUNRW1wbG95ZWUgTmFtZWRkAgsPDxYCHwAFGk9saXZlIE5ldHdvcmsgU3lzdGVtIFN0dWR5ZGQCDQ9kFgJmD2QWAgIDDw8WAh8ABSQ8aT4qUGhvdG8gc2l6ZTogMTAwIHggMTIwIHBpeGVsczwvaT5kZAIPDw8WAh8ABQtFbXBsb3llZSBJRGRkAhEPDxYCHwAFC1RFTVBfZXphY2N0ZGQCEw8PFgIfAAUHQ291bnRyeWRkAhUPDxYCHwAFCVNpbmdhcG9yZWRkAhcPDxYCHwAFB0NvbXBhbnlkZAIZDw8WAh8ABRtDSiBMb2dpc3RpY3MgQXNpYSBQdGUuIEx0ZC5kZAIbDw8WAh8ABQpEZXBhcnRtZW50ZGQCHQ8PFgIfAAUMSVQgRldEICYgSVBTZGQCHw8PFgIfAAULRGVzaWduYXRpb25kZAIhDw8WAh8ABRpPbGl2ZSBOZXR3b3JrIFN5c3RlbSBTdHVkeWRkAiMPDxYCHwAFBUVtYWlsZGQCJQ8PFgIfAAURbWluaG8ucGFya0Bjai5uZXRkZAInDw8WAh8ABQpTdXBlcnZpc29yZGQCKQ8PFgIfAAURQWxleCBMZWUgU2FuZyBTdWJkZAIrDw8WAh8ABRBEaXNwbGF5IExhbmd1YWdlZGQCLQ8QDxYGHg1EYXRhVGV4dEZpZWxkBQhDb2RlRGVzYx4ORGF0YVZhbHVlRmllbGQFBkNvZGVJRB4LXyFEYXRhQm91bmRnZBAVBRFFbmdsaXNoIChFbmdsaXNoKSHnroDkvZPkuK3mlocgKENoaW5lc2UgU2ltcGxpZmllZCki57mB6auU5Lit5paHIChDaGluZXNlIFRyYWRpdGlvbmFsKRLtlZzqta3slrQgKEtvcmVhbikQ4LmE4LiX4LiiIChUaGFpKRUFAmVuBXpoLUNOBXpoLVRXAmtvAnRoFCsDBWdnZ2dnZGQCLw8PFgIfAAUOUGhvbmUgKE9mZmljZSlkZAI1Dw8WAh4MRXJyb3JNZXNzYWdlBRVQaG9uZSAoSG9tZSkgcmVxdWlyZWRkZAI3Dw8WAh8ABQNGYXhkZAI9Dw8WAh8ABUUqWW91ciBpbmZvcm1hdGlvbiBpcyBpbmNvbXBsZXRlLCBwbGVhc2UgZmlsbCBpbiBFbWFpbCwgRXh0IGFuZCBQaG90by5kZBgBBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WAgUHYnRuU2F2ZQUIYnRuQ2xvc2U4Dbb/vvcJ8L6/wxgvHDm7/kBnmg==" />
</div>

<!-- hyunil92 추가 부분 -->

<?php
 // // Web JSON 파일 읽어오기
// $url = 'http://localhost/user_info.php';
// $json_string = file_get_contents($url);
// echo $json_string
?>

<?php

$token = $_GET['uid'];
$name = "";

$str = file_get_contents('http://localhost/user_info.php');
$json = json_decode($str, true); 


// echo '<pre>' . print_r($json, true) . '</pre>';


    foreach ($json as $row) {
		if( $token ==$row['token'])
	  {
           $name =  $row['name'];
	  }
}
 
?> 

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=1ICNiPk_kPUnjbv1bLpMLMm6sz2FselulhoegtBtkSpdnqug65nzgidAk7TodvU8VoMfpD_1ICUX-ewgIS00oQy-Epc1&amp;t=636284921597151108" type="text/javascript"></script>


<script src="/WebResource.axd?d=_bYmBwIye56RZCGzVeEDVvZLELOaMXevwyPtWCfAmgv4gTneTbhuTS8mq7tqYdR1cIud4yiQbrLkBvwh6vBcw0a3KQA1&amp;t=636284921597151108" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=twFX1X2TlhojxqLPtojI9amwntol9qJxLAPpwC-ChbxuKqW0-7Sua9yoe5Qkr5FOvX3AOlA55P6i-d1NVmbiZRGHX9Aqog8-9XcnV3EY6oMjTDwJH7m-nubKyjJ_rakUnI0vFnjPlo6fyDLvu5OszR5SKjUODicMjVTtDr9a8mTozKOW0&amp;t=635845620641720586" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=EvVmOTnqQN_oFhPaRuBOveyA_A1gtMbwWYBZhxKh0AotnUIwK73M7D-FiKRLnCJd0Vp6LMR103NYmLyyqxJ7NPtyJ8cegcODasfH2uMlyR4PxKJsOtHj4LNxbsKrrFGpIQXif_GbOWQdVfbEVqq0hOQc_qg1&amp;t=633111008880000000" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=HYHQ22yOMSpI-DrYSmrj0xqvWqEqsEkAhOpBKvopWpNy1nPwAxailTLctp91xMqUStob9j5Dcw6ZyGnrvv9p0Bf1t_fGWsi3n7shqI6_uP6cweBX23UZNXYcDW0iadCidot3x6apjuSc6eudhaEXyJLhN3aCVwgJH8Bgx503HVQEeCtn0&amp;t=633111008880000000" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="435F5107" />
</div>
        
<script language=javascript>
    if('True' == 'False')
    {
        parent.location = "/ErrorPage/AccessDeny.aspx";
    }
    
    if(parent.frames.length==0)
    {
        if('True' == 'False')
            window.location = "/Default.aspx";
    }
</script>
<div style="display:none;">
UserControl-UserProfile
    </div>

        
        <div>
            <table>
                <tr>
                    <td colspan="4" align="center" class="tdError">
                        <div id="upError">
	
                                
                            
</div>
                    </td>
                </tr>
                <tr>
                    <td colspan="4" class="tdHeader">
                        <span id="lblTitleL">Employee Information</span>
                    </td>
                </tr>
                <tr>
                    <td class="tdLblNormal">
                        <span id="lblEmployeeNameL">Employee Name</span>
                    </td>
                    <td class="tdTxtNormal" colspan="2">
                        <!-- <span id="lblName"><?php echo $json_string[0]['name'];?></span> -->
						<span id="lblName"><?php echo $row['name'];?></span>
                    </td>
                    <td class="tdTxtNormal" rowspan="5" style="vertical-align: middle;" align="left">
                        <div id="upLogo">
	
                                    <img id="imgPic" src="http://192.168.0.181/Image/NoPhoto.gif" style="border-color:LightGrey;border-width:1px;border-style:Solid;height:120px;width:100px;" />
                                <br />
                                <font color="gray" style="display:none">
                                    <span id="lblPhotoSizeL"><i>*Photo size: 100 x 120 pixels</i></span>
                                </font>&nbsp;
                            
</div>
                    </td>
                </tr>
                <tr>
                    <td class="tdLblNormal">
                        <span id="lblEmployeeIDL">Employee ID</span></td>
                    <td class="tdTxtNormal" colspan="2">
                        <span id="lblName"><?php echo $row['id'];?></span>
                    </td>
                </tr>
                <tr>
                    <td class="tdLblNormal">
                        <span id="lblCountryL">Country</span></td>
                    <td class="tdTxtNormal" colspan="2">
                        <span id="lblName"><?php echo $row['country'];?></span>
                    </td>
                </tr>
                <tr>
                    <td class="tdLblNormal">
                        <span id="lblCompanyL">Company</span></td>
                    <td class="tdTxtNormal" colspan="2">
                        <span id="lblName"><?php echo $row['company'];?></span>
                    </td>
                </tr>
                <tr>
                    <td class="tdLblNormal">
                        <span id="lblDepartmentL">Department</span></td>
                    <td class="tdTxtNormal" colspan="2">
                        <span id="lblDepartment">KX IT Department</span>
                    </td>
                </tr>
                <tr>
                    <td class="tdLblNormal">
                        <span id="lblDesignationL">Designation</span></td>
                    <td class="tdTxtNormal">
                        <span id="lblDesignation">G-Link Web for MSA</span>
                    </td>
                    <td class="tdLblNormal">
                        <span id="lblEmailL">Email</span></td>
                    <td class="tdTxtNormal">
                        <span id="lblName"><?php echo $row['email'];?></span>
                    </td>
                </tr>
                <tr>

                    <td class="tdLblNormal">
                        <span id="lblSupervisorL">Supervisor</span></td>
                    <td class="tdTxtNormal">
                        <span id="lblSupervisor">aether</span>
                    </td>
                    <td class="tdLblNormal">
                        <span id="lblLanguageL">Display Language</span></td>
                    <td class="tdTxtNormal" >
                        <select name="cboLanguage" id="cboLanguage" style="width:145px;">
	<option selected="selected" value="en">English (English)</option>
	<option value="zh-CN">简体中文 (Chinese Simplified)</option>
	<option value="zh-TW">繁體中文 (Chinese Traditional)</option>
	<option value="ko">한국어 (Korean)</option>
	<option value="th">ไทย (Thai)</option>

</select>
                    </td>
                </tr>
                <tr>
                    <td class="tdLblNormal">
                        <span id="lblOfficeTel">Phone (Office)</span></td>
                    <td class="tdTxtNormal">
                        <input name="txtExt" type="text" maxlength="30" id="txtExt" style="width:140px;" />
                        
                        <span id="rfvExt" style="color:Red;visibility:hidden;">*</span>
                    </td>
                    <td class="tdLblNormal">
                        <span id="lblFaxL">Fax</span></td>
                    <td class="tdTxtNormal">
                        <input name="txtFax" type="text" maxlength="30" id="txtFax" style="width:140px;" />
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="4" class="tdBreak">
                    </td>
                </tr>
                <tr>
                    <td colspan="4" class="tdLine">
                    </td>
                </tr> 
                <tr>
                    <td colspan="4" class="tdFont">
                        
                    </td>
                </tr>
                <tr>
                    <td colspan="4" class="tdBreak" align="center">
                        <div id="urWait" style="visibility:hidden;display:block;">
	
                                <img src="/Image/ajax-loader.gif" />
                            
</div>
                    </td>
                </tr>
                <tr>
                    <td colspan="4" class="tdGrid" align="center">
                        <input type="image" name="btnSave" id="btnSave" src="http://192.168.0.181/Image/btnUpdate_C.gif" align="middle" onclick="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;btnSave&quot;, &quot;&quot;, true, &quot;Page&quot;, &quot;&quot;, false, false))" style="border-width:0px;" />
                        <input type="image" name="btnClose" id="btnClose" src="http://192.168.0.181/Image/btnClose_C.gif" align="middle" onclick="window.close();" style="border-width:0px;" />
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <div id="VSummary" style="color:Red;display:none;">

</div>
                    </td>
                </tr>
            </table>
        </div>
    
<script type="text/javascript">
//<![CDATA[
var Page_ValidationSummaries =  new Array(document.getElementById("VSummary"));
var Page_Validators =  new Array(document.getElementById("rfvExt"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var rfvExt = document.all ? document.all["rfvExt"] : document.getElementById("rfvExt");
rfvExt.controltovalidate = "txtExt";
rfvExt.errormessage = "Phone (Home) required";
rfvExt.validationGroup = "Page";
rfvExt.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
rfvExt.initialvalue = "";
var VSummary = document.all ? document.all["VSummary"] : document.getElementById("VSummary");
VSummary.showmessagebox = "True";
VSummary.showsummary = "False";
VSummary.validationGroup = "Page";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        Sys.Application.initialize();
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.FilteredTextBoxBehavior, {"ValidChars":"()-+1234567890 ","id":"ftbeExt"}, null, null, $get("txtExt"));
});
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.FilteredTextBoxBehavior, {"ValidChars":"()-+1234567890 ","id":"ftbeFax"}, null, null, $get("txtFax"));
});
//]]>
</script>
</form>
</body>
<script language="javascript">
    window.focus();
</script>
</html>
